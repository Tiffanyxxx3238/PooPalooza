# The-MySQL-Workshop
A simple, low tech approach to quickly get you working with MySQL with real world examples from those who use it every day.
