INSERT INTO climate_history VALUES
('2020-03-12', 18.5, 62.0),
('2020-03-13', 19.0, 63.5);
