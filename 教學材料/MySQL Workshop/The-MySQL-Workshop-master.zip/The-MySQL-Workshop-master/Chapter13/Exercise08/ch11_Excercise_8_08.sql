# source world.sql
SHOW TABLES FROM world;
DESCRIBE world.city;
