USE test;

DESCRIBE animals;

INSERT INTO animals (name, id) VALUES('Camel', 2);

INSERT INTO animals (id) VALUES(3);

SELECT * FROM animals;
