util.importJson('the_beatles.json');
\rehash
db.the_beatles.find();
