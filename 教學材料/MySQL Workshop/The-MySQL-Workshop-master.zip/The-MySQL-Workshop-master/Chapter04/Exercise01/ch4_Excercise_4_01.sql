USE world;

DESCRIBE countrylanguage;

SELECT Language FROM countrylanguage LIMIT 5;
