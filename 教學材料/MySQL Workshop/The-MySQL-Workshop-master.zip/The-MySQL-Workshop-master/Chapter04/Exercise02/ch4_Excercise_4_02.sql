USE world;

DESCRIBE country;

SELECT Name, SurfaceArea FROM country WHERE Region='Western Europe';
