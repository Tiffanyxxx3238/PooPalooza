SELECT * FROM backuppractice.country;

SELECT * FROM backuppractice.country 
  WHERE `Country Code`="AUS"

DELETE FROM backuppractice.country 
  WHERE `Country Code`="AUS";

SELECT * FROM backuppractice.country 
  WHERE `Country Code`="AUS";
