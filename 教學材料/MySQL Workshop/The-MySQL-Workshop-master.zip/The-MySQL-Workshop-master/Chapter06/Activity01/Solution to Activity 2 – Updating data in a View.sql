UPDATE vw_members_all
SET DOB = "1990-01-11"
WHERE ID=7;
