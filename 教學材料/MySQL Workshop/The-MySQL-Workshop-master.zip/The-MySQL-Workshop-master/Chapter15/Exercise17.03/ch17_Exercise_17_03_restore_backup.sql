CREATE SCHEMA coffeeprefs_dev;
USE coffeeprefs_dev;
SOURCE C:\Temp\coffeeprefs.sql
SHOW TABLES;
