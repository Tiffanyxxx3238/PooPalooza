USE world;
DELETE FROM city;
SELECT * FROM city;
-- below works after restore
SELECT COUNT(*) FROM city;