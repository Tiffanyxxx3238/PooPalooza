<?php require_once( "SNIPPETS/HEADER.php" ); ?>

<div class="jumbotron jumbotron-fluid" id="HomeSection">
  <h1 class="display-3 jumbotronTextOnImages text-center" id="JumbotronHeading">Heading</h1>

  <img id="JumbotronImage" src="https://res.cloudinary.com/sonarsystems/image/upload/v1497973720/Youtube_2Bnew_2Bheader_u0ruil.png" />
</div>

<?php require_once( "SNIPPETS/FOOTER.php" ); ?>