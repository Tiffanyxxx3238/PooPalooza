<?php require_once( "SNIPPETS/HEADER.php" ); ?>

<div class="container">
	<div class="row">
		<div class="col-12 text-center">
			<h1>The Best Photo Gallery In The World</h1>
		</div>
	</div>

	<div class="row">
		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail">
		</div>
	</div>

	<div class="row">
		<div class="col-12 text-center">
			<nav>
				<ul class="pagination">
			    	<li class="page-item"><a class="page-link" href="#">Previous</a></li>
			    	<li class="page-item"><a class="page-link" href="#">1</a></li>
			    	<li class="page-item"><a class="page-link" href="#">2</a></li>
			    	<li class="page-item"><a class="page-link" href="#">3</a></li>
			    	<li class="page-item"><a class="page-link" href="#">Next</a></li>
			  	</ul>
			</nav>
		</div>
	</div>
</div>

<?php require_once( "SNIPPETS/FOOTER.php" ); ?>