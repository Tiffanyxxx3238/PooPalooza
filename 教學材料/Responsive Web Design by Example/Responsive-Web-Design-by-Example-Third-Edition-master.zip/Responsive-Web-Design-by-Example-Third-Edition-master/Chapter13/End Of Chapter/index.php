<?php require_once( "SNIPPETS/HEADER.php" ); ?>

<div class="container">
	<div class="row">
		<div class="col-12 text-center">
			<h1>The Best Photo Gallery In The World</h1>
		</div>
	</div>

	<div class="row">
		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>

		<div class="col-lg-2 col-md-3 col-sm-6 col-12 thumbnailContainer">
			<img src="http://res.cloudinary.com/dmliyxggm/image/upload/v1511804166/photo1_bcjm1j.jpg" class="img-thumbnail thumbnailImage">
		</div>
	</div>

	<div class="row">
		<div class="col-12 text-center">
			<nav>
				<ul class="pagination" id="PaginationList">
			    	<li class="page-item"><a class="page-link" href="#">Previous</a></li>
			    	<li class="page-item"><a class="page-link" href="#">1</a></li>
			    	<li class="page-item"><a class="page-link" href="#">2</a></li>
			    	<li class="page-item"><a class="page-link" href="#">3</a></li>
			    	<li class="page-item"><a class="page-link" href="#">Next</a></li>
			  	</ul>
			</nav>
		</div>
	</div>
</div>

<div class="modal fade" role="dialog" id="LightBoxModal" aria-hidden="true">
  	<div class="modal-dialog modal-lg" role="document">
    	<div class="modal-content">
      		<div class="modal-header">
        		<h5 class="modal-title" id="ImageTitle">Modal title</h5>
        		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          			<span aria-hidden="true">&times;</span>
        		</button>
      		</div>

      		<div class="modal-body">
        		<img class="img-thumbnail" id="ImageShowcase" />
      		</div>
    	</div>
  	</div>
</div>

<?php require_once( "SNIPPETS/FOOTER.php" ); ?>