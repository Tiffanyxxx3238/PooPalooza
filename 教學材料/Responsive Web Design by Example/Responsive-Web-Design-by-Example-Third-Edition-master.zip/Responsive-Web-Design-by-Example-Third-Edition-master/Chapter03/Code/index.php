<?php require_once( "SNIPPETS/HEADER.php" ); ?>

<div class="container">
  <div class="row">
    <h1>Hello, world!</h1>
  </div>
</div>

<?php require_once( "SNIPPETS/FOOTER.php" ); ?>